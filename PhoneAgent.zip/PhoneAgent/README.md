# Telefon Ajanı (PhoneAgent)

Kendi yapay zeka API'nizle telefonu otonom kullanan Android uygulaması.

## Derleme
1. Android Studio (Koala veya üstü) ile bu klasörü açın → Gradle Sync.
2. Telefonu USB ile bağlayıp Run ▶ (veya Build > Build APK).

## Kurulum
1. Uygulamayı açın: sağlayıcı, Base URL, API anahtarı, model adını girip "Ayarları kaydet".
2. "Erişilebilirlik" → Telefon Ajanı'nı açın.
   Android 13+ ve APK ile yüklediyseniz önce: Uygulama bilgisi → ⋮ → "Kısıtlı ayarlara izin ver".
3. Görev yazın, örn: "ZArchiver'ı aç, Download klasörüne gir ve oyunumun APK'sını kur." → Başlat.

## Base URL örnekleri
- OpenAI:      https://api.openai.com/v1
- OpenRouter:  https://openrouter.ai/api/v1
- DeepSeek:    https://api.deepseek.com/v1
- Ollama:      http://TELEFON_YA_DA_PC_IP:11434/v1
- Anthropic:   https://api.anthropic.com   (sağlayıcı: Anthropic)

## Güvenlik
- Ekranın üstündeki kırmızı "DURDUR" düğmesi ajanı her an durdurur.
- Şifre alanlarına yazmaz; sil/öde/gönder gibi öğelerde onay ister (ayarlanabilir).
- API anahtarı cihazda şifreli saklanır ve yalnızca sizin belirttiğiniz URL'ye gönderilir.
