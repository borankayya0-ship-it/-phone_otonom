package com.phoneagent

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class Provider(val label: String) {
    OPENAI("OpenAI uyumlu (OpenAI, OpenRouter, DeepSeek, Groq, Ollama…)"),
    ANTHROPIC("Anthropic (Claude)")
}

data class AgentSettings(
    val provider: Provider,
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    val confirmRisky: Boolean,
    val maxSteps: Int = 40
)

/** API anahtarı dahil tüm ayarları şifreli (AES-256) saklar. */
class SettingsStore(private val context: Context) {

    private val prefs: SharedPreferences = openPrefs()

    private fun openPrefs(): SharedPreferences = try {
        createPrefs()
    } catch (e: Exception) {
        // Anahtar deposu bozulduysa (yedekten geri yükleme vb.) sıfırla
        context.deleteSharedPreferences(FILE)
        createPrefs()
    }

    private fun createPrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun load(): AgentSettings = AgentSettings(
        provider = runCatching { Provider.valueOf(prefs.getString("provider", "") ?: "") }
            .getOrDefault(Provider.OPENAI),
        baseUrl = prefs.getString("baseUrl", "https://api.openai.com/v1").orEmpty(),
        apiKey = prefs.getString("apiKey", "").orEmpty(),
        model = prefs.getString("model", "").orEmpty(),
        confirmRisky = prefs.getBoolean("confirmRisky", true)
    )

    fun save(s: AgentSettings) {
        prefs.edit()
            .putString("provider", s.provider.name)
            .putString("baseUrl", s.baseUrl)
            .putString("apiKey", s.apiKey)
            .putString("model", s.model)
            .putBoolean("confirmRisky", s.confirmRisky)
            .apply()
    }

    fun loadTask(): String = prefs.getString("task", "").orEmpty()

    fun saveTask(task: String) {
        prefs.edit().putString("task", task).apply()
    }

    private companion object {
        const val FILE = "agent_secure_prefs"
    }
}
