package com.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Ekrandaki tek bir öğe. */
class UiNode(
    val info: AccessibilityNodeInfo,
    val bounds: Rect,
    val label: String,
    val body: String,
    val isPassword: Boolean
) {
    val isRisky: Boolean
        get() {
            val tokens = label.split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
            return tokens.any { token -> RISKY.any { it.equals(token, ignoreCase = true) } }
        }

    private companion object {
        val RISKY = setOf(
            "delete", "remove", "uninstall", "purchase", "buy", "pay", "payment", "transfer",
            "send", "erase", "reset", "format",
            "sil", "kaldır", "öde", "ödeme", "satın", "gönder", "sıfırla"
        )
    }
}

class ScreenSnapshot(val packageName: String, val text: String, val nodes: List<UiNode>)

/**
 * Cihazı kontrol eden erişilebilirlik servisi:
 * ekranı okur, dokunur, kaydırır, yazar, uygulama açar ve ajan döngüsünü çalıştırır.
 */
class AgentAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    @Volatile
    private var lastEventAt = 0L

    private var overlayView: View? = null
    private var statusView: TextView? = null

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onServiceConnected() {
        super.onServiceConnected()
        AgentBus.service = this
        AgentBus.log("Erişilebilirlik servisi bağlandı")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Kendi arayüzümüzün (overlay) olayları "ekran değişti" sayılmasın
        if (event?.packageName?.toString() == packageName) return
        lastEventAt = SystemClock.uptimeMillis()
    }

    override fun onInterrupt() {
        stopTask()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopTask()
        hideOverlay()
        AgentBus.service = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        hideOverlay()
        AgentBus.service = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- görev kontrolü

    fun startTask(task: String) {
        if (job?.isActive == true) {
            AgentBus.log("⚠️ Zaten çalışan bir görev var")
            return
        }
        val settings = SettingsStore(this).load()
        AgentBus.running.value = true
        showOverlay()
        job = scope.launch {
            try {
                AgentEngine(this@AgentAccessibilityService, settings).run(task)
            } catch (e: CancellationException) {
                AgentBus.log("⏹ Görev durduruldu")
                throw e
            } catch (e: Exception) {
                AgentBus.log("❌ Hata: ${e.message}")
            } finally {
                hideOverlay()
                AgentBus.running.value = false
            }
        }
    }

    fun stopTask() {
        job?.cancel()
    }

    // ---------------------------------------------------------------- ekran okuma

    suspend fun readScreen(): ScreenSnapshot = withContext(Dispatchers.Default) {
        var found: AccessibilityNodeInfo? = null
        for (attempt in 0 until 5) {
            found = rootInActiveWindow
            if (found != null) break
            delay(300)
        }
        val dm = resources.displayMetrics
        val header = "Screen size: ${dm.widthPixels}x${dm.heightPixels}"
        val root = found
            ?: return@withContext ScreenSnapshot(
                "unknown",
                "$header\n(no accessible window — the screen may be locked, protected, or transitioning)",
                emptyList()
            )

        val nodes = mutableListOf<UiNode>()
        collect(root, nodes, 0)

        val pkg = root.packageName?.toString() ?: "unknown"
        val sb = StringBuilder()
        sb.appendLine("App: $pkg")
        sb.appendLine(header)
        if (nodes.isEmpty()) {
            sb.appendLine("(no readable UI elements — a game, canvas or protected screen. Use tap(x,y).)")
        }
        nodes.forEachIndexed { i, n -> sb.appendLine("[$i] ${n.body}") }
        if (nodes.size >= MAX_NODES) sb.appendLine("(list truncated — scroll to see more)")
        ScreenSnapshot(pkg, sb.toString(), nodes)
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<UiNode>, depth: Int) {
        if (node == null || out.size >= MAX_NODES || depth > 40) return

        if (node.isVisibleToUser) {
            val password = node.isPassword
            val text = if (password) "•••" else clean(node.text)
            val desc = clean(node.contentDescription)
            val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) clean(node.hintText) else ""
            val id = node.viewIdResourceName?.substringAfter(":id/").orEmpty()
            val interesting = text.isNotEmpty() || desc.isNotEmpty() || node.isClickable ||
                node.isLongClickable || node.isEditable || node.isScrollable || node.isCheckable

            val bounds = Rect().also { node.getBoundsInScreen(it) }
            if (interesting && !bounds.isEmpty) {
                val flags = buildList {
                    if (node.isClickable) add("click")
                    if (node.isLongClickable) add("longclick")
                    if (node.isEditable) add("edit")
                    if (node.isScrollable) add("scroll")
                    if (node.isCheckable) add(if (node.isChecked) "checked" else "unchecked")
                    if (!node.isEnabled) add("disabled")
                }
                val cls = node.className?.toString()?.substringAfterLast('.').orEmpty()
                val body = buildString {
                    append(cls)
                    if (text.isNotEmpty()) append(" \"").append(text).append('"')
                    if (desc.isNotEmpty() && desc != text) append(" (desc: ").append(desc).append(')')
                    if (hint.isNotEmpty() && node.isEditable) append(" (hint: ").append(hint).append(')')
                    if (id.isNotEmpty()) append(" id=").append(id)
                    if (flags.isNotEmpty()) append(" {").append(flags.joinToString(",")).append('}')
                    append(" @").append(bounds.centerX()).append(',').append(bounds.centerY())
                }
                val label = listOf(text, desc, hint, id).firstOrNull { it.isNotEmpty() } ?: cls
                out.add(UiNode(node, bounds, label, body, password))
            }
        }
        for (i in 0 until node.childCount) {
            collect(node.getChild(i), out, depth + 1)
        }
    }

    private fun clean(cs: CharSequence?): String =
        cs?.toString()?.replace(Regex("\\s+"), " ")?.trim()?.take(100).orEmpty()

    /** Arayüz olayları sakinleşene kadar bekler. */
    suspend fun awaitIdle(quietMs: Long = 600, timeoutMs: Long = 5000) {
        val start = SystemClock.uptimeMillis()
        delay(500)
        while (SystemClock.uptimeMillis() - start < timeoutMs) {
            if (SystemClock.uptimeMillis() - lastEventAt >= quietMs) return
            delay(150)
        }
    }

    // ---------------------------------------------------------------- eylemler

    suspend fun click(node: UiNode, long: Boolean): Boolean {
        node.info.refresh()
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        var current: AccessibilityNodeInfo? = node.info
        var depth = 0
        while (current != null && depth < 4) {
            val able = if (long) current.isLongClickable else current.isClickable
            if (able && current.isEnabled && current.performAction(action)) return true
            current = current.parent
            depth++
        }
        // Yedek: koordinata gerçek dokunuş
        return tap(node.bounds.centerX(), node.bounds.centerY(), if (long) 700 else 60)
    }

    suspend fun tap(x: Int, y: Int, durationMs: Long = 60): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return gesture(path, durationMs)
    }

    suspend fun scroll(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        // direction = içeriğin hangi tarafının görüneceği ("down" → parmak yukarı kayar)
        val p = when (direction.lowercase()) {
            "down" -> floatArrayOf(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.28f)
            "up" -> floatArrayOf(w * 0.5f, h * 0.28f, w * 0.5f, h * 0.72f)
            "right" -> floatArrayOf(w * 0.8f, h * 0.5f, w * 0.2f, h * 0.5f)
            "left" -> floatArrayOf(w * 0.2f, h * 0.5f, w * 0.8f, h * 0.5f)
            else -> return false
        }
        val path = Path().apply {
            moveTo(p[0], p[1])
            lineTo(p[2], p[3])
        }
        return gesture(path, 350)
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val description = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
                .build()
            val dispatched = dispatchGesture(
                description,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!dispatched && cont.isActive) cont.resume(false)
        }

    fun setText(node: UiNode, text: String, submit: Boolean): Boolean {
        val info = node.info
        info.refresh()
        info.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        info.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = info.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            info.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun openApp(query: String): String {
        val q = query.trim()
        if (q.isEmpty()) return "Hata: uygulama adı boş"
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(q, ignoreCase = true) }
            ?: apps.firstOrNull { it.activityInfo.packageName.equals(q, ignoreCase = true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(q, ignoreCase = true) }
        if (match == null) {
            val names = apps.map { it.loadLabel(pm).toString() }.distinct().sorted().take(60)
            return "Uygulama bulunamadı. Yüklü uygulamalar: ${names.joinToString(", ")}"
        }
        val pkg = match.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return "Hata: başlatılamıyor ($pkg)"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(intent)
            "açıldı: ${match.loadLabel(pm)} ($pkg)"
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
    }

    fun pressBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    // ---------------------------------------------------------------- overlay (durdur düğmesi + onay)

    fun setStatus(text: String) {
        statusView?.text = text
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun overlayParams(gravity: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        this.gravity = gravity
        this.y = y
    }

    private fun showOverlay() {
        if (overlayView != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val status = TextView(this).apply {
                text = "Ajan çalışıyor…"
                setTextColor(Color.WHITE)
                textSize = 12f
                maxLines = 2
                maxWidth = dp(190)
            }
            val stop = TextView(this).apply {
                text = "■ DURDUR"
                setTextColor(Color.WHITE)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = rounded(0xFFD32F2F.toInt(), 16)
                setOnClickListener { stopTask() }
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(6), dp(6), dp(6))
                background = rounded(0xCC000000.toInt(), 22)
                addView(status)
                addView(
                    stop,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { marginStart = dp(10) }
                )
            }
            wm.addView(row, overlayParams(Gravity.TOP or Gravity.CENTER_HORIZONTAL, dp(28)))
            overlayView = row
            statusView = status
        } catch (e: Exception) {
            AgentBus.log("⚠️ Overlay gösterilemedi: ${e.message}")
        }
    }

    private fun hideOverlay() {
        val view = overlayView ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (_: Exception) {
        }
        overlayView = null
        statusView = null
    }

    /** Kullanıcıdan ekran üstü onay ister (60 sn içinde cevap yoksa reddedilir). */
    suspend fun confirm(message: String): Boolean {
        val result = CompletableDeferred<Boolean>()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = buildConfirmView(message) { result.complete(it) }
        return try {
            wm.addView(view, overlayParams(Gravity.CENTER, 0))
            withTimeoutOrNull(60_000) { result.await() } ?: false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        } finally {
            try {
                wm.removeView(view)
            } catch (_: Exception) {
            }
        }
    }

    private fun buildConfirmView(message: String, onResult: (Boolean) -> Unit): View {
        fun button(label: String, color: Int, value: Boolean) = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = rounded(color, 18)
            setOnClickListener { onResult(value) }
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(
                button("REDDET", 0xFF616161.toInt(), false),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(12) }
            )
            addView(button("İZİN VER", 0xFF2E7D32.toInt(), true))
        }
        val text = TextView(this).apply {
            this.text = message
            setTextColor(Color.WHITE)
            textSize = 14f
            maxWidth = dp(280)
            setPadding(0, 0, 0, dp(14))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(0xF2212121.toInt(), 20)
            addView(text)
            addView(buttons)
        }
    }

    private companion object {
        const val MAX_NODES = 200
    }
}
