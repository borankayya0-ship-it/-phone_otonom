package com.phoneagent

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

open class LlmException(message: String) : Exception(message)
class RetryableLlmException(message: String) : LlmException(message)

/**
 * Tek bir "system + user" isteği gönderip metin yanıtı döndürür.
 * OpenAI uyumlu (/chat/completions) ve Anthropic (/v1/messages) formatlarını destekler.
 */
class LlmClient(private val settings: AgentSettings) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    suspend fun complete(system: String, user: String): String {
        var last: LlmException? = null
        for (attempt in 1..3) {
            try {
                return once(system, user)
            } catch (e: RetryableLlmException) {
                last = e
                delay(1500L * attempt)
            }
        }
        throw last ?: LlmException("Bilinmeyen model hatası")
    }

    private suspend fun once(system: String, user: String): String {
        val request = buildRequest(system, user)
        val (code, body) = try {
            val response = http.newCall(request).await()
            withContext(Dispatchers.IO) {
                response.use { it.code to (it.body?.string().orEmpty()) }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            throw RetryableLlmException("Ağ hatası: ${e.message}")
        } catch (e: IllegalArgumentException) {
            throw LlmException("Geçersiz URL: ${settings.baseUrl}")
        }

        if (code in 200..299) {
            return try {
                parse(body)
            } catch (e: Exception) {
                throw LlmException("Yanıt çözümlenemedi: ${body.take(200)}")
            }
        }
        val message = "HTTP $code: ${extractError(body)}"
        if (code == 429 || code >= 500) throw RetryableLlmException(message)
        throw LlmException(message)
    }

    private fun endpoint(): String {
        val base = settings.baseUrl.trim().trimEnd('/')
        return when (settings.provider) {
            Provider.OPENAI ->
                if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
            Provider.ANTHROPIC -> when {
                base.endsWith("/messages") -> base
                base.endsWith("/v1") -> "$base/messages"
                else -> "$base/v1/messages"
            }
        }
    }

    private fun buildRequest(system: String, user: String): Request {
        val json = MEDIA_JSON.toMediaType()
        val builder = Request.Builder().url(endpoint())
        return when (settings.provider) {
            Provider.OPENAI -> {
                val body = JSONObject()
                    .put("model", settings.model)
                    .put(
                        "messages",
                        JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", user))
                    )
                if (settings.apiKey.isNotBlank()) {
                    builder.header("Authorization", "Bearer ${settings.apiKey}")
                }
                builder.post(body.toString().toRequestBody(json)).build()
            }
            Provider.ANTHROPIC -> {
                val body = JSONObject()
                    .put("model", settings.model)
                    .put("max_tokens", 1024)
                    .put("system", system)
                    .put(
                        "messages",
                        JSONArray().put(JSONObject().put("role", "user").put("content", user))
                    )
                builder
                    .header("x-api-key", settings.apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(json))
                    .build()
            }
        }
    }

    private fun parse(body: String): String {
        val root = JSONObject(body)
        return when (settings.provider) {
            Provider.OPENAI -> {
                val message = root.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                when (val content = message.opt("content")) {
                    is String -> content
                    is JSONArray -> (0 until content.length())
                        .joinToString("") { content.getJSONObject(it).optString("text") }
                    else -> ""
                }
            }
            Provider.ANTHROPIC -> {
                val blocks = root.getJSONArray("content")
                (0 until blocks.length())
                    .map { blocks.getJSONObject(it) }
                    .filter { it.optString("type") == "text" }
                    .joinToString("") { it.optString("text") }
            }
        }
    }

    private fun extractError(body: String): String = try {
        when (val error = JSONObject(body).opt("error")) {
            is JSONObject -> error.optString("message", body.take(300))
            is String -> error
            else -> body.take(300)
        }
    } catch (e: Exception) {
        body.take(300)
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }

    private companion object {
        const val MEDIA_JSON = "application/json; charset=utf-8"
    }
}
