package com.phoneagent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.phoneagent.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var store: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = SettingsStore(this)

        b.spProvider.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Provider.values().map { it.label }
        )

        val s = store.load()
        b.spProvider.setSelection(s.provider.ordinal)
        b.etUrl.setText(s.baseUrl)
        b.etKey.setText(s.apiKey)
        b.etModel.setText(s.model)
        b.swConfirm.isChecked = s.confirmRisky
        b.etTask.setText(store.loadTask())

        b.btnSave.setOnClickListener {
            store.save(readForm())
            toast("Ayarlar şifreli olarak kaydedildi")
        }
        b.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        b.btnAppInfo.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        b.btnStart.setOnClickListener { startTask() }
        b.btnStop.setOnClickListener { AgentBus.service?.stopTask() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    AgentBus.logs.collect { lines ->
                        b.tvLog.text = lines.asReversed().joinToString("\n")
                    }
                }
                launch {
                    AgentBus.running.collect { running ->
                        b.btnStart.isEnabled = !running
                        b.btnStop.isEnabled = running
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        b.tvStatus.text = if (AgentBus.service != null) {
            "✅ Erişilebilirlik servisi aktif"
        } else {
            "⚠️ Erişilebilirlik servisi kapalı. \"Erişilebilirlik\" düğmesinden Telefon Ajanı'nı açın. " +
                "Android 13+ ve APK olarak yüklediyseniz önce \"Uygulama bilgisi\" → ⋮ → \"Kısıtlı ayarlara izin ver\"."
        }
    }

    private fun startTask() {
        val settings = readForm()
        val task = b.etTask.text.toString().trim()
        when {
            !settings.baseUrl.startsWith("http") -> return toast("Base URL http(s):// ile başlamalı")
            settings.model.isEmpty() -> return toast("Model adını yazın")
            task.isEmpty() -> return toast("Ajana bir görev yazın")
        }
        store.save(settings)
        store.saveTask(task)

        val service = AgentBus.service
        if (service == null) {
            toast("Önce erişilebilirlik servisini açın")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        AgentBus.clear()
        service.startTask(task)
    }

    private fun readForm() = AgentSettings(
        provider = Provider.values()[b.spProvider.selectedItemPosition],
        baseUrl = b.etUrl.text.toString().trim(),
        apiKey = b.etKey.text.toString().trim(),
        model = b.etModel.text.toString().trim(),
        confirmRisky = b.swConfirm.isChecked
    )

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
