package com.phoneagent

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Servis ile arayüz arasındaki ortak durum: günlük, çalışma durumu ve servis referansı. */
object AgentBus {
    @Volatile
    var service: AgentAccessibilityService? = null

    val logs = MutableStateFlow<List<String>>(emptyList())
    val running = MutableStateFlow(false)

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(message: String) {
        val time = synchronized(timeFormat) { timeFormat.format(Date()) }
        val line = "$time  $message"
        logs.update { (it + line).takeLast(300) }
    }

    fun clear() {
        logs.value = emptyList()
    }
}
